#!/usr/bin/env python3


with open("/home/section5_cron/output.txt","w") as fd:
    fd.write("\n------\nTEST\n------\n")


with open("/root/root.txt","r") as fd:
    data = fd.readlines()

with open("/home/section5_cron/root.txt","w") as fd:
    fd.write(data[0].replace('\n',''))
