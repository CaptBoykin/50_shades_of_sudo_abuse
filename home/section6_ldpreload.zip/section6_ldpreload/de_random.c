int rand(){
    return 42; //the most random number in the universe
}
