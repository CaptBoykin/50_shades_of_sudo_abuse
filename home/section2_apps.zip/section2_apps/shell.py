import pty


pty.spawn('/bin/bash')
